import { Navbar } from '../components/Navbar';
import { Footer } from '../components/Footer';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { MapPin, Phone, Mail, Clock, Instagram, MessageCircle } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';

export const Contacto = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    toast.success('¡Mensaje enviado! Te responderemos pronto.');
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: 'Dirección',
      content: 'Buenos Aires, Argentina',
      link: 'https://maps.google.com'
    },
    {
      icon: Phone,
      title: 'Teléfono',
      content: '+54 9 11 1234-5678',
      link: 'tel:+5491112345678'
    },
    {
      icon: Mail,
      title: 'Email',
      content: 'info@tokioshowroom.com',
      link: 'mailto:info@tokioshowroom.com'
    },
    {
      icon: Clock,
      title: 'Horarios',
      content: 'Lun - Vie: 9:00 - 18:00',
      link: null
    }
  ];

  const socialLinks = [
    {
      icon: Instagram,
      name: 'Instagram',
      handle: '@tokio.showroomok',
      link: 'https://www.instagram.com/tokio.showroomok/',
      color: 'text-pink-500'
    },
    {
      icon: MessageCircle,
      name: 'WhatsApp',
      handle: '+54 9 11 1234-5678',
      link: 'https://wa.me/5491112345678',
      color: 'text-green-500'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl font-bold mb-4">
              <span className="tokio-gradient bg-clip-text text-transparent">Contactanos</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              ¿Tenés alguna pregunta? ¿Necesitás ayuda con tu pedido? Estamos acá para ayudarte. Contactanos por cualquiera de nuestros canales.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <Card className="tokio-card">
              <CardHeader>
                <CardTitle className="text-2xl">Envianos un Mensaje</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Nombre *</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        required
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="subject">Asunto</Label>
                    <Input
                      id="subject"
                      value={formData.subject}
                      onChange={(e) => setFormData({...formData, subject: e.target.value})}
                      placeholder="¿En qué podemos ayudarte?"
                    />
                  </div>

                  <div>
                    <Label htmlFor="message">Mensaje *</Label>
                    <Textarea
                      id="message"
                      value={formData.message}
                      onChange={(e) => setFormData({...formData, message: e.target.value})}
                      placeholder="Contanos tu consulta..."
                      rows={5}
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full tokio-gradient">
                    Enviar Mensaje
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Contact Info */}
            <div className="space-y-6">
              {/* Contact Details */}
              <Card className="tokio-card">
                <CardHeader>
                  <CardTitle className="text-2xl">Información de Contacto</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {contactInfo.map((info, index) => (
                    <div key={index} className="flex items-center space-x-4">
                      <div className="p-3 rounded-lg bg-tokio-purple/10">
                        <info.icon className="h-6 w-6 text-tokio-purple" />
                      </div>
                      <div>
                        <h3 className="font-semibold">{info.title}</h3>
                        {info.link ? (
                          <a 
                            href={info.link} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-muted-foreground hover:text-tokio-purple tokio-transition"
                          >
                            {info.content}
                          </a>
                        ) : (
                          <p className="text-muted-foreground">{info.content}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Social Media */}
              <Card className="tokio-card">
                <CardHeader>
                  <CardTitle className="text-2xl">Redes Sociales</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {socialLinks.map((social, index) => (
                    <a
                      key={index}
                      href={social.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center space-x-4 p-3 rounded-lg hover:bg-muted/50 tokio-transition group"
                    >
                      <div className="p-3 rounded-lg bg-muted">
                        <social.icon className={`h-6 w-6 ${social.color} group-hover:scale-110 tokio-transition`} />
                      </div>
                      <div>
                        <h3 className="font-semibold">{social.name}</h3>
                        <p className="text-muted-foreground">{social.handle}</p>
                      </div>
                    </a>
                  ))}
                </CardContent>
              </Card>

              {/* FAQ */}
              <Card className="tokio-card">
                <CardHeader>
                  <CardTitle className="text-2xl">Preguntas Frecuentes</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="font-semibold mb-2">¿Cuáles son los tiempos de entrega?</h3>
                    <p className="text-sm text-muted-foreground">Las entregas en CABA son de 24-48hs, al interior del país 3-5 días hábiles.</p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">¿Puedo cambiar o devolver un producto?</h3>
                    <p className="text-sm text-muted-foreground">Sí, tenés 15 días para cambios y devoluciones. El producto debe estar en perfectas condiciones.</p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">¿Tienen local físico?</h3>
                    <p className="text-sm text-muted-foreground">Trabajamos principalmente online, pero podemos coordinar encuentros para ver productos.</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};