import { Navbar } from '../components/Navbar';
import { Footer } from '../components/Footer';
import { Card, CardContent } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Heart, Users, Truck, Shield } from 'lucide-react';

export const Nosotros = () => {
  const values = [
    {
      icon: Heart,
      title: 'Pasión por la Moda',
      description: 'Amamos lo que hacemos y se nota en cada producto que seleccionamos.'
    },
    {
      icon: Users,
      title: 'Comunidad',
      description: 'Creemos en construir una comunidad de personas que comparten nuestro estilo.'
    },
    {
      icon: Truck,
      title: 'Envío Rápido',
      description: 'Enviamos tu pedido lo más rápido posible a todo el país.'
    },
    {
      icon: Shield,
      title: 'Calidad Garantizada',
      description: 'Todos nuestros productos pasan por estrictos controles de calidad.'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Hero Section */}
          <div className="text-center mb-16">
            <h1 className="text-4xl font-bold mb-4">
              Sobre <span className="tokio-gradient bg-clip-text text-transparent">Nosotros</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-8">
              TOKIO Showroom nació de la pasión por la moda urbana y el deseo de ofrecer piezas únicas que reflejen la personalidad de cada persona. Desde 2020, hemos estado comprometidos con brindar la mejor experiencia de compra y productos de calidad excepcional.
            </p>
            <Badge className="tokio-gradient text-white text-lg px-6 py-2">
              Más de 3 años en el mercado
            </Badge>
          </div>

          {/* Story Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
            <div>
              <h2 className="text-3xl font-bold mb-6">Nuestra Historia</h2>
              <div className="space-y-4 text-muted-foreground">
                <p>
                  Todo comenzó en un pequeño local en el corazón de Buenos Aires. Con la visión de democratizar la moda urbana de calidad, TOKIO Showroom se propuso crear un espacio donde la creatividad y el estilo se encuentren.
                </p>
                <p>
                  Hoy, después de años de crecimiento y aprendizaje, seguimos manteniendo esa esencia original: ofrecer productos únicos, con atención personalizada y la calidad que nuestros clientes merecen.
                </p>
                <p>
                  Nuestro compromiso va más allá de la venta. Creemos en construir relaciones duraderas con nuestra comunidad, escuchando sus necesidades y evolucionando junto a ellos.
                </p>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <div className="relative">
                <img 
                  src="/src/assets/hoodie-black.jpg" 
                  alt="TOKIO Showroom" 
                  className="rounded-lg shadow-lg w-full max-w-md"
                />
                <div className="absolute inset-0 tokio-gradient opacity-20 rounded-lg"></div>
              </div>
            </div>
          </div>

          {/* Values Section */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-center mb-12">
              Nuestros <span className="tokio-gradient bg-clip-text text-transparent">Valores</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {values.map((value, index) => (
                <Card key={index} className="tokio-card text-center group hover:scale-105 tokio-transition">
                  <CardContent className="p-6">
                    <div className="mb-4">
                      <value.icon className="h-12 w-12 mx-auto text-tokio-purple group-hover:scale-110 tokio-transition" />
                    </div>
                    <h3 className="text-lg font-bold mb-2">{value.title}</h3>
                    <p className="text-sm text-muted-foreground">{value.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Stats Section */}
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-12">
              TOKIO en <span className="tokio-gradient bg-clip-text text-transparent">Números</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="p-6">
                <div className="text-4xl font-bold tokio-gradient bg-clip-text text-transparent mb-2">1000+</div>
                <p className="text-muted-foreground">Clientes Satisfechos</p>
              </div>
              <div className="p-6">
                <div className="text-4xl font-bold tokio-gradient bg-clip-text text-transparent mb-2">50+</div>
                <p className="text-muted-foreground">Productos Únicos</p>
              </div>
              <div className="p-6">
                <div className="text-4xl font-bold tokio-gradient bg-clip-text text-transparent mb-2">3</div>
                <p className="text-muted-foreground">Años de Experiencia</p>
              </div>
              <div className="p-6">
                <div className="text-4xl font-bold tokio-gradient bg-clip-text text-transparent mb-2">24/7</div>
                <p className="text-muted-foreground">Atención al Cliente</p>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};