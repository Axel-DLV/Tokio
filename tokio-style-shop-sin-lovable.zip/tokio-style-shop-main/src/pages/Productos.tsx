import { Navbar } from '../components/Navbar';
import { ProductGrid } from '../components/ProductGrid';
import { Footer } from '../components/Footer';

export const Productos = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4">
              Nuestros <span className="tokio-gradient bg-clip-text text-transparent">Productos</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Descubrí nuestra colección de ropa urbana de alta calidad. Cada pieza está cuidadosamente seleccionada para ofrecerte el mejor estilo y comodidad.
            </p>
          </div>
          <ProductGrid />
        </div>
      </main>
      <Footer />
    </div>
  );
};