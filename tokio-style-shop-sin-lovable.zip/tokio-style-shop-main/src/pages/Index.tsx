import { Store } from './Store';

const Index = () => {
  return <Store />;
};

export default Index;
