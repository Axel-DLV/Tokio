import { useState } from 'react';
import { useStore } from '../store/useStore';
import { Navbar } from '../components/Navbar';
import { Hero } from '../components/Hero';
import { ProductGrid } from '../components/ProductGrid';
import { Cart } from '../components/Cart';
import { AdminPanel } from '../components/AdminPanel';
import { LoginModal } from '../components/LoginModal';
import { Footer } from '../components/Footer';
import { Button } from '../components/ui/button';
import { ShoppingBag, User, LogOut, X } from 'lucide-react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '../components/ui/sheet';

export const Store = () => {
  const { user, logout, isAdminMode, getCartItemsCount } = useStore();
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showCart, setShowCart] = useState(false);
  const cartItemsCount = getCartItemsCount();

  const handleUserClick = () => {
    if (user) {
      logout();
    } else {
      setShowLoginModal(true);
    }
  };

  if (isAdminMode && user?.isAdmin) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <AdminPanel />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Fixed Action Buttons */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col space-y-3">
        {/* Cart Button */}
        <Sheet open={showCart} onOpenChange={setShowCart}>
          <SheetTrigger asChild>
            <Button
              size="lg"
              className="relative tokio-gradient hover:opacity-90 tokio-transition rounded-full h-14 w-14 shadow-lg"
            >
              <ShoppingBag className="h-6 w-6" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-6 w-6 flex items-center justify-center">
                  {cartItemsCount}
                </span>
              )}
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-full sm:w-[540px] p-0">
            <SheetHeader className="p-6 pb-0">
              <SheetTitle className="text-2xl">
                Tu <span className="tokio-gradient bg-clip-text text-transparent">Carrito</span>
              </SheetTitle>
            </SheetHeader>
            <div className="h-full overflow-y-auto">
              <Cart />
            </div>
          </SheetContent>
        </Sheet>

        {/* User Button */}
        <Button
          size="lg"
          variant={user ? "default" : "outline"}
          className={`rounded-full h-14 w-14 shadow-lg ${user ? 'tokio-gradient' : ''}`}
          onClick={handleUserClick}
        >
          {user ? <LogOut className="h-6 w-6" /> : <User className="h-6 w-6" />}
        </Button>
      </div>

      <main>
        <Hero />
        <ProductGrid />
      </main>

      <Footer />

      <LoginModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
      />
    </div>
  );
};