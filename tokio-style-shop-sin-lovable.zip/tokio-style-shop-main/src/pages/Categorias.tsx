import { Navbar } from '../components/Navbar';
import { Footer } from '../components/Footer';
import { Card, CardContent } from '../components/ui/card';
import { Badge } from '../components/ui/badge';

export const Categorias = () => {
  const categories = [
    {
      name: 'Remeras',
      description: 'Remeras cómodas y con estilo para uso diario',
      count: 15,
      image: '/src/assets/tshirt-purple.jpg'
    },
    {
      name: 'Hoodies',
      description: 'Buzos con capucha perfectos para el frío',
      count: 8,
      image: '/src/assets/hoodie-black.jpg'
    },
    {
      name: 'Pantalones',
      description: 'Pantalones urbanos de alta calidad',
      count: 12,
      image: '/src/assets/pants-black.jpg'
    },
    {
      name: 'Camperas',
      description: 'Camperas y chaquetas para todas las ocasiones',
      count: 6,
      image: '/src/assets/jacket-denim.jpg'
    },
    {
      name: 'Accesorios',
      description: 'Gorras, bufandas y más complementos',
      count: 10,
      image: '/src/assets/cap-white.jpg'
    },
    {
      name: 'Buzos',
      description: 'Buzos cómodos para relajarse con estilo',
      count: 7,
      image: '/src/assets/sweatshirt-pink.jpg'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4">
              Nuestras <span className="tokio-gradient bg-clip-text text-transparent">Categorías</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Explorá todas nuestras categorías de productos. Desde básicos hasta piezas statement, tenemos todo lo que necesitás.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category, index) => (
              <Card key={index} className="tokio-card group cursor-pointer hover:scale-105 tokio-transition">
                <CardContent className="p-0">
                  <div className="relative overflow-hidden rounded-t-lg">
                    <img 
                      src={category.image} 
                      alt={category.name}
                      className="w-full h-48 object-cover group-hover:scale-110 tokio-transition"
                    />
                    <div className="absolute top-4 right-4">
                      <Badge className="tokio-gradient text-white">
                        {category.count} productos
                      </Badge>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-2">{category.name}</h3>
                    <p className="text-muted-foreground">{category.description}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};