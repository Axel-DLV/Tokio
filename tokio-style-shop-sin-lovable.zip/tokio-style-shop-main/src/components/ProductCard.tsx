import { useState } from 'react';
import { Product } from '../types';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent, CardFooter } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { useStore } from '../store/useStore';
import { ShoppingCart, Heart, Edit } from 'lucide-react';
import { toast } from 'sonner';

interface ProductCardProps {
  product: Product;
}

export const ProductCard = ({ product }: ProductCardProps) => {
  const { addToCart, isAdminMode } = useStore();
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [isLiked, setIsLiked] = useState(false);

  const handleAddToCart = () => {
    if (!selectedSize || !selectedColor) {
      toast.error('Por favor selecciona talle y color');
      return;
    }
    
    addToCart(product, selectedSize, selectedColor);
    toast.success('Producto agregado al carrito');
    setSelectedSize('');
    setSelectedColor('');
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('es-AR', {
      style: 'currency',
      currency: 'ARS'
    }).format(price);
  };

  return (
    <Card className="group tokio-card hover:tokio-glow tokio-transition cursor-pointer overflow-hidden">
      <div className="relative overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-64 object-cover group-hover:scale-105 tokio-transition"
        />
        
        {/* Admin Edit Button */}
        {isAdminMode && (
          <Button
            size="sm"
            className="absolute top-2 right-2 tokio-gradient"
          >
            <Edit className="h-4 w-4" />
          </Button>
        )}
        
        {/* Like Button */}
        <Button
          variant="ghost"
          size="sm"
          className={`absolute top-2 ${isAdminMode ? 'right-12' : 'right-2'} bg-white/80 hover:bg-white`}
          onClick={() => setIsLiked(!isLiked)}
        >
          <Heart
            className={`h-4 w-4 ${isLiked ? 'fill-red-500 text-red-500' : 'text-gray-600'}`}
          />
        </Button>

        {/* Stock Badge */}
        {product.stock < 5 && (
          <Badge variant="destructive" className="absolute bottom-2 left-2">
            ¡Últimas unidades!
          </Badge>
        )}
      </div>

      <CardContent className="p-4">
        <div className="space-y-2">
          <h3 className="font-semibold text-lg">{product.name}</h3>
          <p className="text-muted-foreground text-sm">{product.description}</p>
          <p className="text-2xl font-bold tokio-gradient bg-clip-text text-transparent">
            {formatPrice(product.price)}
          </p>
        </div>

        {/* Size Selection */}
        <div className="mt-4 space-y-2">
          <label className="text-sm font-medium">Talle:</label>
          <Select value={selectedSize} onValueChange={setSelectedSize}>
            <SelectTrigger>
              <SelectValue placeholder="Seleccionar talle" />
            </SelectTrigger>
            <SelectContent>
              {product.sizes.map((size) => (
                <SelectItem key={size} value={size}>
                  {size}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Color Selection */}
        <div className="mt-4 space-y-2">
          <label className="text-sm font-medium">Color:</label>
          <Select value={selectedColor} onValueChange={setSelectedColor}>
            <SelectTrigger>
              <SelectValue placeholder="Seleccionar color" />
            </SelectTrigger>
            <SelectContent>
              {product.colors.map((color) => (
                <SelectItem key={color} value={color}>
                  {color}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardContent>

      <CardFooter className="p-4 pt-0">
        <Button
          className="w-full tokio-gradient hover:opacity-90 tokio-transition"
          onClick={handleAddToCart}
          disabled={product.stock === 0}
        >
          <ShoppingCart className="h-4 w-4 mr-2" />
          {product.stock === 0 ? 'Sin Stock' : 'Agregar al Carrito'}
        </Button>
      </CardFooter>
    </Card>
  );
};