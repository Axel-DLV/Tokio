import { useState } from 'react';
import { CartItem, PaymentMethod } from '../types';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { CreditCard, Building, Banknote, CheckCircle } from 'lucide-react';
import { useStore } from '../store/useStore';
import { toast } from 'sonner';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  total: number;
  cartItems: CartItem[];
}

export const PaymentModal = ({ isOpen, onClose, total, cartItems }: PaymentModalProps) => {
  const { clearCart } = useStore();
  const [step, setStep] = useState<'info' | 'payment' | 'success'>('info');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('mercadopago');
  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    email: '',
    phone: '',
    address: ''
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('es-AR', {
      style: 'currency',
      currency: 'ARS'
    }).format(price);
  };

  const handleInfoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerInfo.name || !customerInfo.email || !customerInfo.phone) {
      toast.error('Por favor completá todos los campos obligatorios');
      return;
    }
    setStep('payment');
  };

  const handlePaymentSubmit = () => {
    // Simulate payment processing
    setTimeout(() => {
      setStep('success');
      clearCart();
      toast.success('¡Pedido realizado con éxito!');
    }, 2000);
  };

  const handleClose = () => {
    setStep('info');
    setCustomerInfo({
      name: '',
      email: '',
      phone: '',
      address: ''
    });
    onClose();
  };

  const paymentMethods = [
    {
      id: 'mercadopago' as PaymentMethod,
      name: 'MercadoPago',
      icon: CreditCard,
      description: 'Tarjetas de crédito y débito',
      discount: 0
    },
    {
      id: 'transferencia' as PaymentMethod,
      name: 'Transferencia Bancaria',
      icon: Building,
      description: '10% de descuento',
      discount: 0.1
    },
    {
      id: 'efectivo' as PaymentMethod,
      name: 'Efectivo',
      icon: Banknote,
      description: '15% de descuento (contraentrega)',
      discount: 0.15
    }
  ];

  const selectedPaymentMethod = paymentMethods.find(pm => pm.id === paymentMethod);
  const finalTotal = total * (1 - (selectedPaymentMethod?.discount || 0));

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">
            {step === 'info' && 'Información de Entrega'}
            {step === 'payment' && 'Método de Pago'}
            {step === 'success' && '¡Pedido Confirmado!'}
          </DialogTitle>
        </DialogHeader>

        {step === 'info' && (
          <form onSubmit={handleInfoSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Nombre completo *</Label>
                <Input
                  id="name"
                  value={customerInfo.name}
                  onChange={(e) => setCustomerInfo({...customerInfo, name: e.target.value})}
                  required
                />
              </div>
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={customerInfo.email}
                  onChange={(e) => setCustomerInfo({...customerInfo, email: e.target.value})}
                  required
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="phone">Teléfono *</Label>
              <Input
                id="phone"
                value={customerInfo.phone}
                onChange={(e) => setCustomerInfo({...customerInfo, phone: e.target.value})}
                placeholder="+54 9 11 1234-5678"
                required
              />
            </div>

            <div>
              <Label htmlFor="address">Dirección de entrega</Label>
              <Textarea
                id="address"
                value={customerInfo.address}
                onChange={(e) => setCustomerInfo({...customerInfo, address: e.target.value})}
                placeholder="Calle, número, piso, departamento, localidad, provincia"
                rows={3}
              />
            </div>

            <Button type="submit" className="w-full tokio-gradient">
              Continuar al Pago
            </Button>
          </form>
        )}

        {step === 'payment' && (
          <div className="space-y-6">
            {/* Order Summary */}
            <Card className="tokio-card">
              <CardHeader>
                <CardTitle className="text-lg">Resumen del Pedido</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  {cartItems.map((item, index) => (
                    <div key={index} className="flex justify-between">
                      <span>{item.product.name} ({item.size}, {item.color}) x{item.quantity}</span>
                      <span>{formatPrice(item.product.price * item.quantity)}</span>
                    </div>
                  ))}
                  <div className="border-t pt-2 font-bold">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span>{formatPrice(total)}</span>
                    </div>
                    {selectedPaymentMethod?.discount > 0 && (
                      <div className="flex justify-between text-green-600">
                        <span>Descuento ({(selectedPaymentMethod.discount * 100).toFixed(0)}%):</span>
                        <span>-{formatPrice(total * selectedPaymentMethod.discount)}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-lg tokio-gradient bg-clip-text text-transparent">
                      <span>Total:</span>
                      <span>{formatPrice(finalTotal)}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Payment Methods */}
            <div>
              <Label className="text-lg font-semibold">Método de Pago</Label>
              <RadioGroup value={paymentMethod} onValueChange={(value) => setPaymentMethod(value as PaymentMethod)} className="mt-4">
                {paymentMethods.map((method) => (
                  <Card key={method.id} className="tokio-card">
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-3">
                        <RadioGroupItem value={method.id} id={method.id} />
                        <method.icon className="h-6 w-6" />
                        <div className="flex-1">
                          <Label htmlFor={method.id} className="cursor-pointer">
                            <div className="flex justify-between items-center">
                              <div>
                                <p className="font-semibold">{method.name}</p>
                                <p className="text-sm text-muted-foreground">{method.description}</p>
                              </div>
                              {method.discount > 0 && (
                                <span className="text-green-600 font-semibold">
                                  -{(method.discount * 100).toFixed(0)}%
                                </span>
                              )}
                            </div>
                          </Label>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </RadioGroup>
            </div>

            {/* Payment Instructions */}
            {paymentMethod === 'transferencia' && (
              <Card className="bg-blue-50 dark:bg-blue-950">
                <CardContent className="p-4">
                  <h4 className="font-semibold mb-2">Datos para transferencia:</h4>
                  <div className="space-y-1 text-sm">
                    <p><strong>Banco:</strong> Banco Galicia</p>
                    <p><strong>Titular:</strong> Tokio Showroom S.A.</p>
                    <p><strong>CBU:</strong> 0070055430004123456789</p>
                    <p><strong>Alias:</strong> TOKIO.SHOWROOM</p>
                  </div>
                </CardContent>
              </Card>
            )}

            {paymentMethod === 'efectivo' && (
              <Card className="bg-green-50 dark:bg-green-950">
                <CardContent className="p-4">
                  <h4 className="font-semibold mb-2">Pago en efectivo:</h4>
                  <p className="text-sm">El pago se realizará al momento de la entrega. Nuestro repartidor llevará el cambio necesario.</p>
                </CardContent>
              </Card>
            )}

            <Button 
              className="w-full tokio-gradient hover:opacity-90"
              onClick={handlePaymentSubmit}
            >
              Confirmar Pedido - {formatPrice(finalTotal)}
            </Button>
          </div>
        )}

        {step === 'success' && (
          <div className="text-center space-y-6">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto" />
            <div>
              <h3 className="text-2xl font-bold mb-2">¡Pedido Confirmado!</h3>
              <p className="text-muted-foreground">
                Te enviamos un email con los detalles de tu pedido.
              </p>
            </div>
            
            <div className="space-y-2 text-sm">
              <p><strong>Número de pedido:</strong> #TK{Date.now().toString().slice(-6)}</p>
              <p><strong>Total pagado:</strong> {formatPrice(finalTotal)}</p>
              <p><strong>Método de pago:</strong> {selectedPaymentMethod?.name}</p>
            </div>

            <Button className="w-full tokio-gradient" onClick={handleClose}>
              Continuar Comprando
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};