import { Instagram, Facebook, Twitter, Mail, Phone, MapPin } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Separator } from './ui/separator';

export const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <h3 className="text-2xl font-bold">
              TOKIO <span className="tokio-gradient bg-clip-text text-transparent">SHOWROOM</span>
            </h3>
            <p className="text-sm opacity-80">
              Tu destino para el mejor streetwear. Calidad premium, diseños únicos y las últimas tendencias urbanas.
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="sm" className="hover:bg-white/10">
                <Instagram className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="sm" className="hover:bg-white/10">
                <Facebook className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="sm" className="hover:bg-white/10">
                <Twitter className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="font-semibold">Enlaces Rápidos</h4>
            <div className="space-y-2 text-sm">
              <a href="#productos" className="block opacity-80 hover:opacity-100 tokio-transition">
                Productos
              </a>
              <a href="#categorias" className="block opacity-80 hover:opacity-100 tokio-transition">
                Categorías
              </a>
              <a href="#nosotros" className="block opacity-80 hover:opacity-100 tokio-transition">
                Sobre Nosotros
              </a>
              <a href="#contacto" className="block opacity-80 hover:opacity-100 tokio-transition">
                Contacto
              </a>
            </div>
          </div>

          {/* Customer Service */}
          <div className="space-y-4">
            <h4 className="font-semibold">Atención al Cliente</h4>
            <div className="space-y-2 text-sm">
              <a href="#" className="block opacity-80 hover:opacity-100 tokio-transition">
                Guía de Talles
              </a>
              <a href="#" className="block opacity-80 hover:opacity-100 tokio-transition">
                Envíos y Devoluciones
              </a>
              <a href="#" className="block opacity-80 hover:opacity-100 tokio-transition">
                Preguntas Frecuentes
              </a>
              <a href="#" className="block opacity-80 hover:opacity-100 tokio-transition">
                Términos y Condiciones
              </a>
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h4 className="font-semibold">Contacto</h4>
            <div className="space-y-3 text-sm">
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4" />
                <span>+54 9 11 1234-5678</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="h-4 w-4" />
                <span>hola@tokioshowroom.com</span>
              </div>
              <div className="flex items-start space-x-2">
                <MapPin className="h-4 w-4 mt-0.5" />
                <span>Palermo, Buenos Aires<br />Argentina</span>
              </div>
            </div>
          </div>
        </div>

        <Separator className="my-8 opacity-20" />

        {/* Newsletter */}
        <div className="text-center space-y-4 mb-8">
          <h4 className="font-semibold">Suscribite a nuestro Newsletter</h4>
          <p className="text-sm opacity-80 max-w-md mx-auto">
            Recibí las últimas novedades, ofertas exclusivas y tips de styling.
          </p>
          <div className="flex max-w-md mx-auto">
            <Input
              placeholder="Tu email"
              className="rounded-r-none bg-white/10 border-white/20 text-white placeholder:text-white/60"
            />
            <Button className="rounded-l-none tokio-gradient">
              Suscribirse
            </Button>
          </div>
        </div>

        <Separator className="my-8 opacity-20" />

        {/* Bottom */}
        <div className="flex flex-col md:flex-row justify-between items-center text-sm opacity-80">
          <p>&copy; 2024 Tokio Showroom. Todos los derechos reservados.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="hover:opacity-100 tokio-transition">Política de Privacidad</a>
            <a href="#" className="hover:opacity-100 tokio-transition">Términos de Uso</a>
          </div>
        </div>
      </div>
    </footer>
  );
};