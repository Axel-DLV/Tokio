import { ShoppingBag, User, Menu, X, Settings } from 'lucide-react';
import { Button } from './ui/button';
import { useStore } from '../store/useStore';
import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';

export const Navbar = () => {
  const { cart, user, isAdminMode, toggleAdminMode, getCartItemsCount } = useStore();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const cartItemsCount = getCartItemsCount();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <h1 className="text-2xl font-bold tokio-gradient bg-clip-text text-transparent">
              TOKIO
            </h1>
            <span className="ml-2 text-xs bg-tokio-purple text-white px-2 py-1 rounded-full">
              SHOWROOM
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link 
              to="/productos" 
              className={`tokio-transition ${isActive('/productos') ? 'text-tokio-purple font-semibold' : 'text-foreground hover:text-tokio-purple'}`}
            >
              Productos
            </Link>
            <Link 
              to="/categorias" 
              className={`tokio-transition ${isActive('/categorias') ? 'text-tokio-purple font-semibold' : 'text-foreground hover:text-tokio-purple'}`}
            >
              Categorías
            </Link>
            <Link 
              to="/nosotros" 
              className={`tokio-transition ${isActive('/nosotros') ? 'text-tokio-purple font-semibold' : 'text-foreground hover:text-tokio-purple'}`}
            >
              Nosotros
            </Link>
            <Link 
              to="/contacto" 
              className={`tokio-transition ${isActive('/contacto') ? 'text-tokio-purple font-semibold' : 'text-foreground hover:text-tokio-purple'}`}
            >
              Contacto
            </Link>
          </div>

          {/* Right Side - Cart, User, Admin */}
          <div className="flex items-center space-x-4">
            {user?.isAdmin && (
              <Button
                variant={isAdminMode ? "default" : "outline"}
                size="sm"
                onClick={toggleAdminMode}
                className={isAdminMode ? "tokio-gradient" : ""}
              >
                <Settings className="h-4 w-4" />
              </Button>
            )}
            
            {/* Cart */}
            <Button variant="ghost" size="sm" className="relative">
              <ShoppingBag className="h-5 w-5" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-tokio-purple text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {cartItemsCount}
                </span>
              )}
            </Button>

            {/* User */}
            <Button variant="ghost" size="sm">
              <User className="h-5 w-5" />
            </Button>

            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-border">
            <div className="flex flex-col space-y-4">
              <Link 
                to="/productos" 
                className={`tokio-transition ${isActive('/productos') ? 'text-tokio-purple font-semibold' : 'text-foreground hover:text-tokio-purple'}`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Productos
              </Link>
              <Link 
                to="/categorias" 
                className={`tokio-transition ${isActive('/categorias') ? 'text-tokio-purple font-semibold' : 'text-foreground hover:text-tokio-purple'}`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Categorías
              </Link>
              <Link 
                to="/nosotros" 
                className={`tokio-transition ${isActive('/nosotros') ? 'text-tokio-purple font-semibold' : 'text-foreground hover:text-tokio-purple'}`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Nosotros
              </Link>
              <Link 
                to="/contacto" 
                className={`tokio-transition ${isActive('/contacto') ? 'text-tokio-purple font-semibold' : 'text-foreground hover:text-tokio-purple'}`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Contacto
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};