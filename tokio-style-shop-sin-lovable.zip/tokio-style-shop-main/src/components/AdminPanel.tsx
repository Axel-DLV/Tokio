import { useState } from 'react';
import { useStore } from '../store/useStore';
import { Product } from '../types';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Plus, Edit, Trash2, Package, DollarSign, Users, ShoppingBag } from 'lucide-react';
import { toast } from 'sonner';

export const AdminPanel = () => {
  const { products, updateProduct, addProduct, deleteProduct } = useStore();
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    price: 0,
    image: '',
    category: '',
    sizes: [] as string[],
    colors: [] as string[],
    description: '',
    stock: 0
  });

  const categories = ['hoodies', 'remeras', 'pantalones', 'buzos', 'camperas', 'accesorios'];
  const availableSizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '28', '30', '32', '34', '36', 'Único'];
  const availableColors = ['Negro', 'Blanco', 'Gris', 'Rosa', 'Violeta', 'Azul', 'Verde', 'Rojo', 'Amarillo', 'Beige', 'Lila'];

  const resetForm = () => {
    setFormData({
      name: '',
      price: 0,
      image: '',
      category: '',
      sizes: [],
      colors: [],
      description: '',
      stock: 0
    });
    setEditingProduct(null);
  };

  const openProductModal = (product?: Product) => {
    if (product) {
      setEditingProduct(product);
      setFormData(product);
    } else {
      resetForm();
    }
    setIsProductModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.category || formData.price <= 0) {
      toast.error('Por favor completá todos los campos obligatorios');
      return;
    }

    if (editingProduct) {
      updateProduct({ ...formData, id: editingProduct.id });
      toast.success('Producto actualizado correctamente');
    } else {
      addProduct(formData);
      toast.success('Producto agregado correctamente');
    }

    setIsProductModalOpen(false);
    resetForm();
  };

  const handleDelete = (productId: string) => {
    if (confirm('¿Estás seguro de que querés eliminar este producto?')) {
      deleteProduct(productId);
      toast.success('Producto eliminado correctamente');
    }
  };

  const handleSizeToggle = (size: string) => {
    setFormData(prev => ({
      ...prev,
      sizes: prev.sizes.includes(size)
        ? prev.sizes.filter(s => s !== size)
        : [...prev.sizes, size]
    }));
  };

  const handleColorToggle = (color: string) => {
    setFormData(prev => ({
      ...prev,
      colors: prev.colors.includes(color)
        ? prev.colors.filter(c => c !== color)
        : [...prev.colors, color]
    }));
  };

  const totalProducts = products.length;
  const totalStock = products.reduce((sum, p) => sum + p.stock, 0);
  const lowStockProducts = products.filter(p => p.stock < 5).length;
  const totalValue = products.reduce((sum, p) => sum + (p.price * p.stock), 0);

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">
          Panel de <span className="tokio-gradient bg-clip-text text-transparent">Administración</span>
        </h1>
        <Button className="tokio-gradient" onClick={() => openProductModal()}>
          <Plus className="h-4 w-4 mr-2" />
          Agregar Producto
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="tokio-card">
          <CardContent className="p-6">
            <div className="flex items-center">
              <Package className="h-8 w-8 text-tokio-purple" />
              <div className="ml-4">
                <p className="text-2xl font-bold">{totalProducts}</p>
                <p className="text-sm text-muted-foreground">Total Productos</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="tokio-card">
          <CardContent className="p-6">
            <div className="flex items-center">
              <ShoppingBag className="h-8 w-8 text-tokio-blue" />
              <div className="ml-4">
                <p className="text-2xl font-bold">{totalStock}</p>
                <p className="text-sm text-muted-foreground">Stock Total</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="tokio-card">
          <CardContent className="p-6">
            <div className="flex items-center">
              <DollarSign className="h-8 w-8 text-tokio-pink" />
              <div className="ml-4">
                <p className="text-2xl font-bold">
                  ${totalValue.toLocaleString('es-AR')}
                </p>
                <p className="text-sm text-muted-foreground">Valor Inventario</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="tokio-card">
          <CardContent className="p-6">
            <div className="flex items-center">
              <Users className="h-8 w-8 text-red-500" />
              <div className="ml-4">
                <p className="text-2xl font-bold">{lowStockProducts}</p>
                <p className="text-sm text-muted-foreground">Stock Bajo</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Products Table */}
      <Card className="tokio-card">
        <CardHeader>
          <CardTitle>Gestión de Productos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {products.map((product) => (
              <div key={product.id} className="flex items-center space-x-4 p-4 border border-border rounded-lg">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-16 h-16 object-cover rounded-lg"
                />
                
                <div className="flex-1">
                  <h3 className="font-semibold">{product.name}</h3>
                  <p className="text-sm text-muted-foreground">{product.category}</p>
                  <div className="flex space-x-2 mt-1">
                    {product.stock < 5 && (
                      <Badge variant="destructive">Stock Bajo</Badge>
                    )}
                    <Badge variant="outline">Stock: {product.stock}</Badge>
                  </div>
                </div>

                <div className="text-right">
                  <p className="font-bold text-lg">${product.price.toLocaleString('es-AR')}</p>
                  <p className="text-sm text-muted-foreground">
                    Talles: {product.sizes.join(', ')}
                  </p>
                </div>

                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openProductModal(product)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-destructive hover:text-destructive"
                    onClick={() => handleDelete(product.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Product Modal */}
      <Dialog open={isProductModalOpen} onOpenChange={setIsProductModalOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingProduct ? 'Editar Producto' : 'Agregar Nuevo Producto'}
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Nombre del Producto *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="price">Precio (ARS) *</Label>
                <Input
                  id="price"
                  type="number"
                  min="0"
                  value={formData.price}
                  onChange={(e) => setFormData({...formData, price: Number(e.target.value)})}
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="category">Categoría *</Label>
                <Select value={formData.category} onValueChange={(value) => setFormData({...formData, category: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar categoría" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category.charAt(0).toUpperCase() + category.slice(1)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="stock">Stock *</Label>
                <Input
                  id="stock"
                  type="number"
                  min="0"
                  value={formData.stock}
                  onChange={(e) => setFormData({...formData, stock: Number(e.target.value)})}
                  required
                />
              </div>
            </div>

            <div>
              <Label htmlFor="image">URL de la Imagen</Label>
              <Input
                id="image"
                value={formData.image}
                onChange={(e) => setFormData({...formData, image: e.target.value})}
                placeholder="https://ejemplo.com/imagen.jpg"
              />
            </div>

            <div>
              <Label htmlFor="description">Descripción</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                rows={3}
              />
            </div>

            <div>
              <Label>Talles Disponibles</Label>
              <div className="grid grid-cols-4 md:grid-cols-6 gap-2 mt-2">
                {availableSizes.map((size) => (
                  <Button
                    key={size}
                    type="button"
                    variant={formData.sizes.includes(size) ? "default" : "outline"}
                    size="sm"
                    className={formData.sizes.includes(size) ? "tokio-gradient" : ""}
                    onClick={() => handleSizeToggle(size)}
                  >
                    {size}
                  </Button>
                ))}
              </div>
            </div>

            <div>
              <Label>Colores Disponibles</Label>
              <div className="grid grid-cols-3 md:grid-cols-4 gap-2 mt-2">
                {availableColors.map((color) => (
                  <Button
                    key={color}
                    type="button"
                    variant={formData.colors.includes(color) ? "default" : "outline"}
                    size="sm"
                    className={formData.colors.includes(color) ? "tokio-gradient" : ""}
                    onClick={() => handleColorToggle(color)}
                  >
                    {color}
                  </Button>
                ))}
              </div>
            </div>

            <Separator />

            <div className="flex space-x-4">
              <Button
                type="button"
                variant="outline"
                className="flex-1"
                onClick={() => setIsProductModalOpen(false)}
              >
                Cancelar
              </Button>
              <Button type="submit" className="flex-1 tokio-gradient">
                {editingProduct ? 'Actualizar' : 'Agregar'} Producto
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};