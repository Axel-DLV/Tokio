import { Button } from './ui/button';
import { ArrowRight, Sparkles } from 'lucide-react';

export const Hero = () => {
  const scrollToProducts = () => {
    document.getElementById('productos')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-72 h-72 tokio-gradient rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-float"></div>
        <div className="absolute top-40 right-10 w-72 h-72 bg-tokio-blue rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-float" style={{animationDelay: '2s'}}></div>
        <div className="absolute -bottom-20 left-20 w-72 h-72 bg-tokio-pink rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-float" style={{animationDelay: '4s'}}></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="space-y-8">
          {/* Badge */}
          <div className="flex justify-center">
            <div className="flex items-center space-x-2 bg-muted px-4 py-2 rounded-full">
              <Sparkles className="h-4 w-4 text-tokio-purple" />
              <span className="text-sm font-medium">Nueva Colección 2024</span>
            </div>
          </div>

          {/* Main Heading */}
          <div className="space-y-4">
            <h1 className="text-6xl md:text-8xl font-bold">
              <span className="block">TOKIO</span>
              <span className="block tokio-gradient bg-clip-text text-transparent">
                SHOWROOM
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto">
              Streetwear premium que define tu estilo. Descubrí piezas únicas que combinan comodidad, 
              calidad y las últimas tendencias urbanas.
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              size="lg"
              className="tokio-gradient hover:opacity-90 tokio-transition text-lg px-8 py-6 rounded-xl"
              onClick={scrollToProducts}
            >
              Explorar Colección
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            
            <Button
              variant="outline"
              size="lg"
              className="text-lg px-8 py-6 rounded-xl border-2 hover:bg-muted tokio-transition"
            >
              Ver Lookbook
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-8 max-w-md mx-auto pt-12">
            <div className="text-center">
              <p className="text-3xl font-bold tokio-gradient bg-clip-text text-transparent">500+</p>
              <p className="text-sm text-muted-foreground">Productos</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold tokio-gradient bg-clip-text text-transparent">2K+</p>
              <p className="text-sm text-muted-foreground">Clientes</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold tokio-gradient bg-clip-text text-transparent">4.9</p>
              <p className="text-sm text-muted-foreground">Rating</p>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-muted-foreground rounded-full flex justify-center">
          <div className="w-1 h-3 bg-muted-foreground rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};