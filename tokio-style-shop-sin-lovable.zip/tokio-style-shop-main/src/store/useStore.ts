import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Product, CartItem, User } from '../types';

// Mock products data
import hoodieBlack from '../assets/hoodie-black.jpg';
import tshirtPurple from '../assets/tshirt-purple.jpg';
import pantsBlack from '../assets/pants-black.jpg';
import capWhite from '../assets/cap-white.jpg';
import sweatshirtPink from '../assets/sweatshirt-pink.jpg';
import jacketDenim from '../assets/jacket-denim.jpg';

const mockProducts: Product[] = [
  {
    id: '1',
    name: 'Hoodie Oversized Negro',
    price: 8500,
    image: hoodieBlack,
    category: 'hoodies',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Negro', 'Gris'],
    description: 'Hoodie oversized de máxima calidad, perfecto para el street style.',
    stock: 15
  },
  {
    id: '2',
    name: 'Remera Purple Vibes',
    price: 4500,
    image: tshirtPurple,
    category: 'remeras',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Violeta', 'Rosa', 'Negro'],
    description: 'Remera con diseño exclusivo, tela de primera calidad.',
    stock: 25
  },
  {
    id: '3',
    name: 'Pantalón Baggy Negro',
    price: 7200,
    image: pantsBlack,
    category: 'pantalones',
    sizes: ['28', '30', '32', '34', '36'],
    colors: ['Negro', 'Gris', 'Beige'],
    description: 'Pantalón baggy cómodo y versátil para cualquier ocasión.',
    stock: 12
  },
  {
    id: '4',
    name: 'Gorra Minimal White',
    price: 3200,
    image: capWhite,
    category: 'accesorios',
    sizes: ['Único'],
    colors: ['Blanco', 'Negro', 'Gris'],
    description: 'Gorra con diseño minimalista y logo bordado.',
    stock: 30
  },
  {
    id: '5',
    name: 'Buzo Rosa Pastel',
    price: 6800,
    image: sweatshirtPink,
    category: 'buzos',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Rosa', 'Blanco', 'Lila'],
    description: 'Buzo oversized en colores pasteles, súper cómodo.',
    stock: 18
  },
  {
    id: '6',
    name: 'Campera Denim Blue',
    price: 9500,
    image: jacketDenim,
    category: 'camperas',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Azul', 'Negro', 'Blanco'],
    description: 'Campera de jean clásica con detalles modernos.',
    stock: 8
  }
];

interface StoreState {
  products: Product[];
  cart: CartItem[];
  user: User | null;
  isAdminMode: boolean;
  
  // Cart actions
  addToCart: (product: Product, size: string, color: string, quantity?: number) => void;
  removeFromCart: (productId: string, size: string, color: string) => void;
  updateCartQuantity: (productId: string, size: string, color: string, quantity: number) => void;
  clearCart: () => void;
  getCartTotal: () => number;
  getCartItemsCount: () => number;
  
  // Product actions
  updateProduct: (product: Product) => void;
  addProduct: (product: Omit<Product, 'id'>) => void;
  deleteProduct: (productId: string) => void;
  
  // User actions
  login: (email: string, password: string) => boolean;
  logout: () => void;
  toggleAdminMode: () => void;
}

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      products: mockProducts,
      cart: [],
      user: null,
      isAdminMode: false,
      
      addToCart: (product, size, color, quantity = 1) => {
        const { cart } = get();
        const existingItem = cart.find(
          item => item.product.id === product.id && item.size === size && item.color === color
        );
        
        if (existingItem) {
          set({
            cart: cart.map(item =>
              item.product.id === product.id && item.size === size && item.color === color
                ? { ...item, quantity: item.quantity + quantity }
                : item
            )
          });
        } else {
          set({
            cart: [...cart, { product, size, color, quantity }]
          });
        }
      },
      
      removeFromCart: (productId, size, color) => {
        set({
          cart: get().cart.filter(
            item => !(item.product.id === productId && item.size === size && item.color === color)
          )
        });
      },
      
      updateCartQuantity: (productId, size, color, quantity) => {
        if (quantity <= 0) {
          get().removeFromCart(productId, size, color);
          return;
        }
        
        set({
          cart: get().cart.map(item =>
            item.product.id === productId && item.size === size && item.color === color
              ? { ...item, quantity }
              : item
          )
        });
      },
      
      clearCart: () => set({ cart: [] }),
      
      getCartTotal: () => {
        return get().cart.reduce((total, item) => total + (item.product.price * item.quantity), 0);
      },
      
      getCartItemsCount: () => {
        return get().cart.reduce((count, item) => count + item.quantity, 0);
      },
      
      updateProduct: (updatedProduct) => {
        set({
          products: get().products.map(product =>
            product.id === updatedProduct.id ? updatedProduct : product
          )
        });
      },
      
      addProduct: (newProduct) => {
        const id = Date.now().toString();
        set({
          products: [...get().products, { ...newProduct, id }]
        });
      },
      
      deleteProduct: (productId) => {
        set({
          products: get().products.filter(product => product.id !== productId)
        });
      },
      
      login: (email, password) => {
        // Mock authentication
        if (email === 'admin@tokio.com' && password === 'admin123') {
          set({
            user: { id: '1', email, isAdmin: true }
          });
          return true;
        }
        return false;
      },
      
      logout: () => {
        set({ user: null, isAdminMode: false });
      },
      
      toggleAdminMode: () => {
        const { user } = get();
        if (user?.isAdmin) {
          set({ isAdminMode: !get().isAdminMode });
        }
      }
    }),
    {
      name: 'tokio-store',
      partialize: (state) => ({
        cart: state.cart,
        user: state.user,
        products: state.products
      })
    }
  )
);